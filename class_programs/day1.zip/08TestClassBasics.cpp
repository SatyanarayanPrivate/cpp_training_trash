#include<iostream>
using namespace std;

class CComplex
{
	double real;
	double imag;
public:
	CComplex() :real(0.0), imag(0.0)
	{
	}
	CComplex(double real, double imag) :real(real), imag(imag)
	{
	}

	CComplex operator+(CComplex & par)
	{

		return CComplex(this->real+par.real,this->imag+par.imag);
	}
	explicit operator double()
	{
		return real + imag;
	}

	friend ostream & operator<<(ostream & os, CComplex & par);
	
};


ostream &  operator<<(ostream & os, CComplex & par)
{
	os << par.real << (par.imag >= 0.0 ? "+" : "") << par.imag << "i" << endl;
	return os;
}

void main8()
{
	CComplex c1(12.6, 13.2);
	CComplex c2(11.5, -7.5);
	cout << c1; //operator<<(cout, c1);
	cout << c2;// << "India" << endl;//operator<<(cout, c2) << "India is great" << endl;;
	cout << "_________________________" << endl;
	CComplex c3 = c1 + c2;// c1.operator+(c2);  //c1 + c2;
	cout << c3;

	double  k = (double)c3;
	cout << "magnitude=" << k << endl;
}