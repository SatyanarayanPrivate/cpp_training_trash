#include<iostream>
using namespace std;

void main5_1()
{
	int x = 10;
	int y = 20;
	//const int *px = &x;//pointer to a constant
	//int const *px = &x;//pointer to a constant
	//int  * const px = &x;//constant pointer
	int const * const px = &x;//constant pointer to a constant
	//px = &y; //l1
	//*px = 999; //l2

	cout << " px=" << px << endl;
	cout << " &x=" << &x << endl;
	cout << " &y=" << &y << endl;
	cout << "________________________" << endl;
	cout << "*px=" << *px << endl;
	cout << "  x=" << x << endl;
	cout << "  y=" << y << endl;
}


void main5_2()
{
	int x = 10;
	int & y = x;
	cout << " &x=" << &x << endl;
	cout << " &y=" << &y << endl;
	cout << "  x=" << x << endl;
	cout << "  y=" << y << endl;
}


int i = 10;
int fun1()
{
	return i;
}

int * fun2()
{
	return &i;
}

int & fun3()
{
	return i;
}



void main5_3()
{
	fun3() = 1000;
	cout << "i=" << i << endl;
}

/*void fx(int,int,int,int=99);
void fx(int, int, int=88, int);
void fx(int, int=77, int , int);
void fx(int=66, int , int, int);*/

//void fx(int = 66, int=55, int=44, int=33);
void fx(int x=44, int y=33, int x1=22, int y1=11)
{
	cout << "   x=" << x << endl;
	cout << "   y=" << y << endl;
	cout << "  x1=" << x1 << endl;
	cout << "  y1=" << y1 << endl;
	cout << "_____________________" << endl;
}

void main5_4()
{
	fx(1, 2, 3, 4);
	fx(11, 22, 33);
	fx(111, 222);
	fx(111);
	fx();
}