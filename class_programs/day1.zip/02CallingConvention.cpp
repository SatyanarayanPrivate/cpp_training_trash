namespace nm2
{
	void fun(int x, int y)
	{
	}//ret	0
	void __cdecl fun1(int x, int y)
	{
	}//ret	0
	void __stdcall fun2(int x, int y)
	{
	}//ret	8
	void __fastcall fun3(int x, int y)
	{
	}//ret	0

	class CA
	{
	public:
		void __thiscall fun4()//_this$ = ecx
		{
		}
		void fun5()
		{
		}
	};
}

void main2()
{
	using namespace nm2;
	fun(10, 20);
	/*
	push	20					; 00000014H
	push	10					; 0000000aH
	call	?fun@@YAXHH@Z				; fun
	add	esp, 8
	*/
	fun(11, 22);
	/*
	push	22					; 00000016H
	push	11					; 0000000bH
	call	?fun@@YAXHH@Z				; fun
	add	esp, 8
	*/
	fun1(1, 2);
	/*
	push	2
	push	1
	call	?fun1@@YAXHH@Z				; fun1
	add	esp, 8
	*/
	fun2(111,222);
	/*
	push	222					; 000000deH
	push	111					; 0000006fH
	call	?fun2@@YGXHH@Z				; fun2
	*/
	fun3(11, 22);
	/*
	mov	edx, 22					; 00000016H
	mov	ecx, 11					; 0000000bH
	call	?fun3@@YIXHH@Z				; fun3
	*/
	CA obj;
	obj.fun4();
	/*
	lea	ecx, DWORD PTR _obj$[ebp]
	call	?fun4@CA@@QAEXXZ			; CA::fun4
	*/
}