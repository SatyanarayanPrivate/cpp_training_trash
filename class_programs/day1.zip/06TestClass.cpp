#include<iostream>
using namespace std;

namespace nm6
{
	class CA
	{

	public:
		int x;
		mutable int y;
		const int c;
		static int s;
		static const int sc;
		CA() :x(10), y(20), c(12)
		{
		}
		//Inspector
		void DisplayValue() const
		{
			//x++;
			y++;
			cout << "x=" << x << endl;
			cout << "y=" << y << endl;
			cout << "___________________" << endl;
		}
		//Mutator
		void ChangeValue()
		{
			x += 10;
			y += 20;
			cout << "x=" << x << endl;
			cout << "y=" << y << endl;
			cout << "___________________" << endl;
		}
		static void StatFun()
		{
			cout << "s=" << s << endl;
			cout << "sc=" << sc << endl;
		}
	};
	int CA::s = 900;
	const int CA::sc = 99;
}

void main6()
{
	using namespace nm6;
	const CA obj;
	obj.y = 987;
	//obj.ChangeValue();
	obj.DisplayValue();

	cout << CA::sc << endl;

	CA::StatFun();
	obj.StatFun();
}
