#include<iostream>
using namespace std;
namespace nm7
{
	class CA
	{
	public:
		CA()
		{
			cout << "CA Default" << endl;
		}
		explicit CA(int x)
		{
			cout << "CA One Param " << endl;
		}
		CA(CA &cpy)
		{
			cout << "CA Copy " << endl;
		}
		/*	CA & operator=(CA &par)
			{
			cout << "CA Assign " << endl;
			return *this;
			}*/
	};
}
void main07()
{
	using namespace nm7;
	CA obj;//default
	CA obj1(10);//one param
	//CA obj2 = 20;//one param
	//obj = 45;//one param
}