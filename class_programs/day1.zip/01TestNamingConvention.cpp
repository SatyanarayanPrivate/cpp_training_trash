namespace nm1
{
	void fun(int x, int y)//fun@@YAXHH@Z
	{
	}
	void fun(double x, double y)//fun@@YAXNN@Z
	{
	}
	void fun(char *x, char* y)//fun@@YAXPAD0@Z
	{
	}
	void fun()//fun@@YAXXZ	
	{
	}
	extern "C++" void MyFun()//MyFun@@YAXXZ	
	{
	}
	extern "C" void OtherFun()//_OtherFun
	{
	}
}
void main1()
{
	using namespace nm1;
	fun(10, 20);
	/*
	call	?fun@@YAXHH@Z				; fun
	*/
	fun(12.34, 45.6);
	/*
	call	?fun@@YAXNN@Z				; fun
	*/
	fun("sachin", "Tendulkar");
	/*
	call	?fun@@YAXPAD0@Z	
	*/
	fun();
	/*
	call	?fun@@YAXXZ	
	*/
	MyFun();
	/*
	call	?MyFun@@YAXXZ
	*/
	OtherFun();
	/*
	call	_OtherFun
	*/
}