#include<iostream>
using namespace std;
namespace nm3
{
	class CA
	{
	public:
		virtual void fun1()
		{
			cout << "fun1 called" << endl;
		}
		virtual void fun2()
		{
			cout << "fun2 called" << endl;
		}
		void fun3()
		{
			cout << "fun3 called" << endl;
		}
	};
}
void main3_1()
{
	using namespace nm3;
	//cout << sizeof(CA) << endl;
	CA obj;
	//((void(*)())*(long*)*(long*)&obj)();
	//step 1 reach the vptr
	long *vp = (long*)&obj;
	//step 2 reach the vtable
	long * vt = (long*)*vp;
	//step 3 reach the function
	typedef void(*FPTR)();
	FPTR fp = (FPTR)vt[2];
	//step 4 call back
	fp();
}


void main3_2()
{
	using namespace nm3;
	CA obj;
	CA &objRef = obj;
	CA *ptr = &obj;
	obj.fun1();
	/*
		lea	ecx, DWORD PTR _obj$[ebp]
		call	?fun1@CA@@UAEXXZ			; CA::fun1
	*/
	obj.fun3();
	/*
		lea	ecx, DWORD PTR _obj$[ebp]
		call	?fun3@CA@@QAEXXZ			; CA::fun3
	*/
	objRef.fun1();//objRef.vptr->vtable[0]()
	/*
		mov	eax, DWORD PTR _objRef$[ebp]
		mov	edx, DWORD PTR [eax]
		mov	esi, esp
		mov	ecx, DWORD PTR _objRef$[ebp]
		mov	eax, DWORD PTR [edx]
		call	eax
		cmp	esi, esp
		call	__RTC_CheckEsp
	*/
	objRef.fun3();
	/*
		mov	ecx, DWORD PTR _objRef$[ebp]
		call	?fun3@CA@@QAEXXZ			; CA::fun3
	*/
	ptr->fun1();//ptr->vptr->vtable[0]()
	/*
		mov	eax, DWORD PTR _ptr$[ebp]
		mov	edx, DWORD PTR [eax]
		mov	esi, esp
		mov	ecx, DWORD PTR _ptr$[ebp]
		mov	eax, DWORD PTR [edx]
		call	eax
		cmp	esi, esp
		call	__RTC_CheckEsp
	*/
	ptr->fun3();
	/*
		mov	ecx, DWORD PTR _ptr$[ebp]
		call	?fun3@CA@@QAEXXZ			; CA::fun3
	*/
}

