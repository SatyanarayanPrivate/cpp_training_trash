#include<iostream>
using namespace std;
namespace nm4
{
	class CA
	{
	public:
		CA()
		{
			cout << "CA Ctor" << endl;
		}
		void fun()
		{
		}
	};
	class CB :public CA
	{
	public:
		CB()//	call	??0CA@@QAE@XZ				; CA::CA
		{
			cout << "CB Ctor" << endl;
		}

	};

	class CC :public CB
	{
	public:
		/*CC()
		{
		cout << "CC Ctor" << endl;
		}*/
	};
}
void main4()
{
	using namespace nm4;
	CC obj;
	/*
	lea	ecx, DWORD PTR _obj$[ebp]
	call	??0CB@@QAE@XZ				; CC::CC
	*/
	obj.fun();
}

namespace nm4_1
{

	class CAT
	{
	public:
		CAT()
		{
			cout << "CAT Ctor" << endl;
		}
	};
	class Apartment
	{
	public:
		Apartment()
		{
			cout << "Apartment" << endl;
		}

	};
	class House :public Apartment
	{
	public:
		virtual void fun()
		{
		}
		House()
		{
			//call	??0Apartment@@QAE@XZ			; Apartment::Apartment
			//mov	DWORD PTR [eax], OFFSET ??_7House@@6B@
			//call	??0CAT@@QAE@XZ				; CAT::CAT
			cout << "House Ctor" << endl;
		}

		CAT obj;
	};

	class Animal
	{
	public:
		/*Animal()
		{
		}*/
		virtual void fun()
		{
		}
	};
}


void main4_1()
{
	using namespace nm4_1;
	House obj;
}