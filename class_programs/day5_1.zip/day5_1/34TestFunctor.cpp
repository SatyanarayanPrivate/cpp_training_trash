#include<iostream>
using namespace std;

void vendorJob(void (*fp)())
{
	cout << "Vendor job started (logIn)" << endl;
	fp();//callback
	cout << "Vendor job completed  (logOut)" << endl;
}



void clientFun()
{
	cout << "client fun called" << endl;
}
void main34_1()
{
	vendorJob(&clientFun);
}

template<typename T>
void vendorJobNew(T obj)
{
	cout << "Vendor job started (logIn New) T=" <<typeid(T).name() << endl;
	obj();//callback
	cout << "Vendor job completed  (logOut New)" << endl;
}
void clientFunNew()
{
	cout << "client fun called New" << endl;
}

class CA
{
public:
	int x;
	int y;
	void operator()()
	{
		cout << "Client Job with state x=" << x << " y=" << y << endl;
	}
};

class FUNCTOR
{
	int & k;
	int & j;
public:
	FUNCTOR(int & k, int & j) :k(k),j(j)
	{
	}
	void operator()()
	{
		cout << "Client Job with state k=" << k << " j=" << j << endl;
	}
};
void main34_2()
{
	int k = 444;
	int j = 555;
	//vendorJobNew(&clientFunNew);
	//CA obj = { 11, 22 };
	//vendorJobNew(obj);
	FUNCTOR func(k, j);

	vendorJobNew(func);
}


void main34_3()
{
	int x = 444;
	int y = 555;
	int z = 66;
	//typeinference
	auto c = 90;
	auto func = [=,&z]()  //lambda expression
	{
		cout << "client fun called New Lambda x="<<x<<" y="<<y<<" z="<<z << endl;
	};
	vendorJobNew(func);
}