#include<iostream>
using namespace std;

namespace nm32
{
	class CA
	{
		int *ptr;
	public:
		CA() :ptr(new int(10))
		{
			cout << "Default" << endl;
		}
		CA(const CA& par) :ptr(new int(*par.ptr))
		{
			cout << "Copy " << endl;
		}
		CA(CA&& par) :ptr(par.ptr)
		{
			par.ptr = NULL;
			cout << "Move this=" << this << " par=" << &par << endl;
		}
		void fun()
		{
			cout << "ptr=" << this->ptr << " this=" << this << endl;
		}
		~CA()
		{
			cout << "Dtor " << " this=" << this << endl;
			delete ptr;
		}
	};

	CA CreateCA()
	{
		CA temp;
		temp.fun();
		return temp;
	}
}

void main32()
{
	using namespace nm32;
	CA obj=CreateCA();
	obj.fun();
}