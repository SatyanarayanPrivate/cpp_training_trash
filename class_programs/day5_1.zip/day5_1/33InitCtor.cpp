#include<iostream>
using namespace std;

namespace nm33
{
	class CA
	{
		int arr[5];
	public:
		CA()
		{
			cout << "Default" << endl;
			arr[0] = 10;
			arr[1] = 20;
			arr[2] = 30;
			arr[3] = 40;
			arr[4] = 50;
		}
		CA(int par1, int par2)
		{
			cout << "Parameter" << endl;
			arr[0] = par1;
			arr[1] = par1;
			arr[2] = par2;
			arr[3] = par2;
			arr[4] = par1;
		}

		CA(initializer_list<int> list)
		{
			cout << "Initialization list ctor " << endl;
			if (list.size() != 5)
				throw invalid_argument("Must be equal to 5");
			initializer_list<int>::iterator it = list.begin();
			for (size_t i = 0; i < list.size(); i++)
			{
				arr[i] = *it;
				it++;
			}
		}
		friend ostream & operator<<(ostream& os, CA & par)
		{
			for (size_t i = 0; i < 5; i++)
			{
				os << "arr[" << i << "]=" << par.arr[i] << endl;
			}
			return os;
		}

	};
}

void main33()
{
	using namespace nm33;
	//CA obj(11,22);
	try
	{
		CA obj = { 33, 44 ,55,66,77};
		cout << obj << endl;
	}
	catch (invalid_argument arg)
	{
		cout << arg.what() << endl;
	}
	
}