#include<iostream>
#include<string>
using namespace std;

namespace nm29
{
	class StackBase
	{
	protected:
		int top;
		StackBase() :top(-1)
		{
		}
	public:
		bool IsEmpty()
		{
			return top == -1;
		}
		bool IsFull()
		{
			return top == 4;
		}
	};

	template<typename T>
	class Stack :public StackBase
	{
		T arr[5];
	public:
		Stack()
		{
			cout << typeid(T).name() << " General for stack" << endl;
		}
		void Push(T val)
		{
			arr[++top] = val;
		}
		T Pop()
		{
			return arr[top--];
		}

		T Peek()
		{
			return arr[top];
		}
		void ListStack()
		{
			for (size_t i = 0; i <= top; i++)
			{
				cout << arr[i] << endl;
			}
		}
		~Stack()
		{
		}
	};



	template<>
	class Stack<int> :public StackBase
	{
		int arr[5];
	public:
		Stack()
		{
			cout << "int Specialized for stack" << endl;
		}
		void Push(int val)
		{
			arr[++top] = val;
		}
		int Pop()
		{
			return arr[top--];
		}

		int Peek()
		{
			return arr[top];
		}
		void ListStack()
		{
			for (size_t i = 0; i <= top; i++)
			{
				cout << arr[i] << endl;
			}
		}
		~Stack()
		{
		}
	};


	template<typename T>
	class Stack<T*> :public StackBase
	{
		T arr[5];
	public:
		Stack()
		{
			cout << typeid(T).name() << " General (pointer) for stack" << endl;
		}
		void Push(T val)
		{
			arr[++top] = val;
		}
		T Pop()
		{
			return arr[top--];
		}

		T Peek()
		{
			return arr[top];
		}
		void ListStack()
		{
			for (size_t i = 0; i <= top; i++)
			{
				cout << arr[i] << endl;
			}
		}
		~Stack()
		{
		}
	};

	class CA
	{
		string Name;
	public:
		CA()
		{
		}
		CA(string Name) :Name(Name)
		{
		}
		void setName(string Name)
		{
			this->Name = Name;
		}
		CA &operator=(CA & par)
		{
			this->Name = par.Name;
			return *this;
		}

		friend ostream & operator<<(ostream& os, CA & par)
		{
			os << "Name=" << par.Name << endl;
			return os;
		}
	};

}
void main29()
{
	using namespace nm29;
	Stack<int> stk;
	stk.Push(10);

	stk.ListStack();
	Stack<CA> stk1;
	CA obj("Sachin");
	stk1.Push(obj);
	obj.setName("Saurav");
	stk1.Push(obj);
	stk1.ListStack();
	Stack<char*> stk2;
	//stk2.Push("Sunil");
	stk2.ListStack();
}