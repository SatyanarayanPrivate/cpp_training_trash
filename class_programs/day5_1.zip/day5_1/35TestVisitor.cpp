#include<iostream>
using namespace std;
namespace nm35
{
	class SA;
	class CURR;
	class DMAT;

	class IVisitor
	{
	public:
		virtual void visit(SA*) = 0;
		virtual void visit(CURR*) = 0;
		virtual void visit(DMAT*) = 0;
	};

	class Bank
	{
	public:
		static IVisitor * visitor;
		virtual void DoBusiness() = 0;
	};
	IVisitor * Bank::visitor = NULL;

	class SA :public Bank
	{
	public:
		virtual void DoBusiness()
		{
			cout << "SA business Started" << endl;
			visitor->visit(this);
			cout << "SA business Completed" << endl;
			cout << "____________________________" << endl;
		}
	};
	class CURR :public Bank
	{
	public:
		virtual void DoBusiness()
		{
			cout << "Curr business Started" << endl;
			visitor->visit(this);
			cout << "Curr business Completed" << endl;
			cout << "____________________________" << endl;
		}
	};
	class DMAT :public Bank
	{
	public:
		virtual void DoBusiness()
		{
			cout << "DMAT business Started" << endl;
			visitor->visit(this);
			cout << "DMAT business Completed" << endl;
			cout << "____________________________" << endl;
		}
	};

	void RegisterVisitor(IVisitor *vis)
	{
		Bank::visitor = vis;
	}
	//-------------------------

	class ChristmasVisitor :public IVisitor
	{
	public:
		virtual void visit(SA*)
		{
			cout << "Christmas visitor for UI SA" << endl;
		}
		virtual void visit(CURR*)
		{
			cout << "Christmas visitor for UI Current" << endl;
		}
		virtual void visit(DMAT*)
		{
			cout << "Christmas visitor for UI DMAT" << endl;
		}
	};


	class DeepavaliVisitor :public IVisitor
	{
	public:
		virtual void visit(SA*)
		{
			cout << "Deepavali visitor for UI SA" << endl;
		}
		virtual void visit(CURR*)
		{
			cout << "Deepavali visitor for UI Current" << endl;
		}
		virtual void visit(DMAT*)
		{
			cout << "Deepavali visitor for UI DMAT" << endl;
		}
	};
}
void  main35()
{
	using namespace nm35;
	ChristmasVisitor deep;
	RegisterVisitor(&deep);
	SA acc1;
	CURR acc2;
	DMAT acc3;
	acc1.DoBusiness();
	acc2.DoBusiness();
	acc3.DoBusiness();

}