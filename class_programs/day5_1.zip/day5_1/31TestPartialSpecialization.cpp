#include<iostream>
using namespace std;

namespace nm31
{
	template<typename T1, typename T2>
	class Dictionary
	{
		T1 key;
		T2 val;
	public:
		Dictionary()
		{
			cout << "key=" << typeid(key).name() << endl;
			cout << "val=" << typeid(val).name() << endl;
			cout << "______________________" << endl;
		}
	};

	template<typename T>
	class MySpecialDictionary :Dictionary < int, T >
	{
	public:
		MySpecialDictionary()
		{
			cout << "Specialization" << endl;
		}
	};
}

void main31()
{
	using namespace nm31;
	Dictionary<int,char*> dict1;
	Dictionary<int, double> dict2;
	Dictionary<double, int> dict3;
	MySpecialDictionary<void(__stdcall *)()> d;
}