#include<iostream>
#include<Windows.h>
#include<functional>
#include<mutex>
#include<thread>
using namespace std;

mutex mute;

class MyClass
{
	int x;
	int y;
public:
	void AddFun()
	{
		for (x = 0; x < 5; x++)
		{
			cout << "AddFun x=" << x << endl;
			Sleep(1000);
		}
		mute.lock();
		for (y = 0; y < 10; y++)
		{
			cout << "AddFun y=" << y << endl;
			Sleep(1000);
		}
		mute.unlock();
	}

	void SubFun()
	{
		mute.lock();
		for (y = -1; y >-10 ; y--)
		{
			cout << "\t\t\tSubFun y=" << y << endl;
			Sleep(1000);
		}
		mute.unlock();
		for (x = -1; x >-5; x--)
		{
			cout << "\t\t\tSubFun x=" << x << endl;
			Sleep(1000);
		}
		
	}
};


void main()
{
	MyClass sm;
	thread t1(&MyClass::AddFun,std::ref(sm));
	thread t2(&MyClass::SubFun, std::ref(sm));
	t1.join();
	t2.join();
}