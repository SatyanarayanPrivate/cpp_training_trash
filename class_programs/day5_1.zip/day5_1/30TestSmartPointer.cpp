#include<iostream>
#include<string>
#include<map>
using namespace std;
namespace nm30
{
	template<typename T>
	class Smart
	{
		T *ptr;
		static map<T*, int> MyMap;
	public:
		Smart() :ptr(new T())
		{
			MyMap[ptr] = 1;
		}
		Smart(const Smart & sm)
			:ptr(sm.ptr)
		{
			int count = MyMap[ptr];
			MyMap[ptr] = count + 1;
		}
		T*operator->()
		{
			return ptr;
		}
		Smart& operator=(Smart & par)
		{
			this->Smart::~Smart();
			this->Smart::Smart(par);
			return *this;
		}
		~Smart()
		{
			if (--MyMap[ptr] == 0)
			{
				MyMap.erase(ptr);
				delete ptr;
			}
		}
	};
	template<typename T>
	map<T*, int> Smart<T>::MyMap;

	class CA
	{
		int *i;
	public:
		CA() :i(new int(10))
		{
			cout << "Ctor default " << endl;
		}
		CA(const CA & par) :i(par.i)
		{
			cout << "Ctor Copy" << endl;
		}
		void fun()
		{
			cout << "CA fun called" << endl;
		}
		CA& operator=(CA & par)
		{
			i = par.i;
			return *this;
		}
		~CA()
		{
			cout << "CA D-tor called" << endl;
			delete i;
		}
	};
}

void main30()
{
	using namespace nm30;
	Smart<CA> s1;
	Smart<CA>  s2(s1);
	Smart<CA>  s3(s2);
	Smart<CA>  s4;
	Smart<CA>  s5;
	Smart<CA>  s6(s5);
	s3 = s4;
	s2 = s6;
}