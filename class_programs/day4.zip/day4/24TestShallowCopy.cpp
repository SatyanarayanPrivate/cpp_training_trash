#include<iostream>
#include<map>
using namespace std;
namespace nm24
{
	class CA
	{
		int *i;
	public:
		CA() :i(new int(10))
		{
			cout << "Ctor default " << endl;
		}
		CA(const CA & par) :i(par.i)
		{
			cout << "Ctor Copy" << endl;
		}
		void fun()
		{
			cout << "CA fun called" << endl;
		}
		CA& operator=(CA & par)
		{
			i = par.i;
			return *this;
		}
		~CA()
		{
			cout << "CA D-tor called" << endl;
			delete i;
		}
	};
	/*
	class Smart
	{
	CA *ptr;
	int * count;
	public:
	Smart() :ptr(new CA()), count(new int(1))
	{
	}
	Smart(const Smart & sm)
	:ptr(sm.ptr), count(sm.count)
	{
	(*count)++;
	}
	CA*operator->()
	{
	return ptr;
	}
	Smart& operator=(Smart & par)
	{
	this->Smart::~Smart();
	this->Smart::Smart(par);
	return *this;
	}
	~Smart()
	{
	if ((--(*count)) == 0)
	{
	delete ptr;
	delete count;
	}
	}
	};
	*/
	class Smart
	{
		CA *ptr;
		static map<CA*, int> MyMap;
	public:
		Smart() :ptr(new CA())
		{
			MyMap[ptr] = 1;
		}
		Smart(const Smart & sm)
			:ptr(sm.ptr)
		{
			int count = MyMap[ptr];
			MyMap[ptr] = count + 1;
		}
		CA*operator->()
		{
			return ptr;
		}
		Smart& operator=(Smart & par)
		{
			this->Smart::~Smart();
			this->Smart::Smart(par);
			return *this;
		}
		~Smart()
		{
			if (--MyMap[ptr] == 0)
			{
				MyMap.erase(ptr);
				delete ptr;
			}
		}
	};
	map<CA*, int> Smart::MyMap;
}
void main24()
{
	using namespace nm24;
	Smart s1;
	Smart s2(s1);
	Smart s3(s2);
	Smart s4;
	Smart s5;
	Smart s6(s5);
	s3 = s4;
	s2 = s6;
}