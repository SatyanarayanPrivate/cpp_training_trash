#include<iostream>
using namespace std;
namespace nm25
{
	class SmartArray
	{
		int arr[5];
	public:
		SmartArray()
		{
			arr[0] = 10;
			arr[1] = 20;
			arr[2] = 30;
			arr[3] = 40;
			arr[4] = 50;
		}

		//----------------------------
		class Helper
		{
			SmartArray *smPtr;
			int index;
		public:
			Helper(SmartArray *smPtr, int index) :smPtr(smPtr), index(index)
			{
			}
			operator int()
			{
				cout << "Reading Security" << endl;
				return smPtr->arr[index];
			}
			Helper & operator=(int par)
			{
				cout << "Writing Security" << endl;
				smPtr->arr[index] = par;
				return *this;
			}
			Helper & operator=(Helper  par)
			{
				cout << "Read/Write Security" << endl;
				smPtr->arr[index] = par.smPtr->arr[par.index];
				return *this;
			}
		};
		//----------------------------
		Helper operator[](int index)
		{
			//Auditing
			return Helper(this, index);
		}
		friend ostream & operator<<(ostream & os, SmartArray & sm)
		{
			for (size_t i = 0; i < 5; i++)
			{
				os << "arr[" << i << "]=" << sm.arr[i] << endl;
			}
			return os;
		}
	};
}
void main25()
{
	using namespace nm25;
	SmartArray arr;
	int x = arr[0];//reading from the array
	arr[1] = 999;//writing to the array
	arr[2] = arr[3];//Read/Write 
	cout << arr << " x=" << x << endl;
}