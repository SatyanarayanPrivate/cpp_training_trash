#include<iostream>
using namespace std;
namespace nm23
{
	class RecCoord;
	class Polar
	{
		double distance;
		double angle;
	public:
		Polar() :distance(0.0), angle(0.0)
		{
		}
		Polar(double distance, double angle)
			:distance(distance), angle(angle*3.14 / 180.0)
		{
		}
		operator RecCoord();

		friend ostream & operator<<(ostream & os, Polar & pol)
		{
			os << "distance=" << pol.distance << " and angle=" << pol.angle << endl;
			return os;
		}
	};

	class RecCoord
	{
		double xCor;
		double yCor;
	public:
		RecCoord() :xCor(0.0), yCor(0.0)
		{
		}
		RecCoord(double xCor, double yCor) :xCor(xCor), yCor(yCor)
		{
		}
		friend ostream & operator<<(ostream & os, RecCoord & rec)
		{
			os << "xCor=" << rec.xCor << " and yCor=" << rec.yCor << endl;
			return os;
		}
		operator Polar()
		{
			return Polar(5.0, 95.0);
		}
	};

	Polar::operator RecCoord()
	{
		return RecCoord(3.0, 4.0);
	}
}
void main23()
{
	using namespace nm23;
	Polar p(5.0,60.0);
	RecCoord r = p;
	RecCoord r2;
	r2 = p;
	cout << p << endl;
	cout << r << endl;
	cout << r2 << endl;
	p = r;
	cout << p << endl;
}