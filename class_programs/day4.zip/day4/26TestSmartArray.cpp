#include<iostream>
using namespace std;
namespace nm26
{
	class SmartArray
	{
		int arr[2][3];
	public:
		SmartArray()
		{
			arr[0][0] = 10;
			arr[0][1] = 20;
			arr[0][2] = 30;
			arr[1][0] = 40;
			arr[1][1] = 50;
			arr[1][2] = 60;
		}

		//----------------------------
		class Helper
		{
			SmartArray *smPtr;
			int index;
		public:
			Helper(SmartArray *smPtr, int index) :smPtr(smPtr), index(index)
			{
			}
			//***********************
			class InnerHelper
			{
				Helper *hlp;
				int index;
			public:
				InnerHelper(Helper *hlp, int index) :hlp(hlp), index(index)
				{
				}
				operator int()
				{
					cout << "Reading Security" << endl;
					return hlp->smPtr->arr[hlp->index][index];
				}
				InnerHelper & operator=(int par)
				{
					cout << "Writing Security" << endl;
					hlp->smPtr->arr[hlp->index][index] = par;
					return *this;
				}
				InnerHelper & operator=(InnerHelper  par)
				{
					cout << "Read/Write Security" << endl;
					hlp->smPtr->arr[hlp->index][index] = par.hlp->smPtr->arr[par.hlp->index][par.index];
					return *this;
				}
			};
			//****************
			InnerHelper operator[](int index)
			{
				return InnerHelper(this, index);
			}
		};

		Helper operator[](int index)
		{
			return Helper(this, index);
		}
		//-----------------------
		friend ostream & operator<<(ostream & os, SmartArray & sm)
		{
			for (size_t i = 0; i < 2; i++)
			{
				for (size_t j = 0; j < 3; j++)
				{
					os << "\t" << sm.arr[i][j];
				}
				os << endl;
			}
			return os;
		}
	};
}
void main26()
{
	using namespace nm26;
	SmartArray arr;
	int x = arr[1][1];//read
	arr[1][0] = 999;//write
	arr[0][0] = arr[1][1];//read/write
	cout << arr;
}