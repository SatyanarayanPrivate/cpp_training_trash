#include<iostream>
#include<string>
using namespace std;
class Employee
{
protected:
	Employee *successor;
	Employee() :successor(NULL)
	{
	}
public:
	void SetSuccessor(Employee *successor)
	{
		this->successor = successor;
	}
	virtual void DoProcess(int amt) = 0;
	void DelegateJob(int amt)
	{
		successor->DoProcess(amt);
	}
};

class Director :public Employee
{
public:
	void DoProcess(int amt)
	{
		if (amt > 500000)
		{
			cout << "(Director)UR Loan Amount can not be processed " << endl;
			
		}
		else
		{
			cout << "UR Loan Amount of " << amt << " was cleared by director" << endl;
		}

	}
};
class Manager :public Employee
{
public:
	void DoProcess(int amt)
	{
		if (amt >300000)
		{
			cout << "(Manager )UR Loan Amount can not be processed " << endl;
			DelegateJob(amt);
		}
		else
		{
			cout << "UR Loan Amount of " << amt << " was cleared by Manager" << endl;
		}

	}
};
class Cahier :public Employee
{
public:
	void DoProcess(int amt)
	{
		if (amt >50000)
		{
			cout << "(Cahier )UR Loan Amount can not be processed " << endl;
			DelegateJob(amt);
		}
		else
		{
			cout << "UR Loan Amount of " << amt << " was cleared by Cahier" << endl;
		}

	}
};
void main()
{
	Cahier cashier;
	Manager manager;
	Director director;

	cashier.SetSuccessor(&manager);
	manager.SetSuccessor(&director);


	cout << "Enter the amount for the loan ";
	int n; cin >> n;
	cashier.DoProcess(n);
}