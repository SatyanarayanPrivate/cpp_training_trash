#include<iostream>
using namespace std;
namespace nm18
{
	class CA
	{
		static void * operator new(size_t size)
		{
			return NULL;
		}
			static void * operator new[](size_t size)
		{
			return NULL;
		}
			static void operator delete(void *pv)
		{

		}
		static void operator delete[](void *pv)
		{

		}
	public:
		CA()
		{
			cout << "CA C-tor" << endl;
		}
		void fun()
		{
			cout << "CA Fun called " << endl;
		}
		~CA()
		{
			cout << "CA D-tor" << endl;
		}
	};

	//CA obj1;
}
void main18()
{
	using namespace nm18;
	CA obj2;
	//CA *ptr = new CA();
	//CA *ptr2 = new CA[5];

	//delete ptr;
	//delete[] ptr2;
}
