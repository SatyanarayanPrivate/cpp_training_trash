#include<iostream>
using namespace std;
namespace nm22
{
	class CA
	{
		int *i;
	public:
		CA() :i(new int(10))
		{
			cout << "Ctor default " << endl;
		}
		CA(const CA & par) :i(new int(*par.i))
		{
			cout << "Ctor Copy" << endl;
		}
		void fun()
		{
			cout << "CA fun called" << endl;
		}
		CA& operator=(CA & par)
		{
			*i = *par.i;
			return *this;
		}
		~CA()
		{
			cout << "CA D-tor called" << endl;
			delete i;
		}
	};

	class Smart
	{
		CA *ptr;
	public:
		Smart() :ptr(new CA())
		{
		}
		Smart(const Smart & sm)
			:ptr(new CA(*sm.ptr))
		{
		}
		CA*operator->()
		{
			return ptr;
		}
		Smart& operator=(Smart & par)
		{
			*ptr = *par.ptr;
			return *this;
		}
		~Smart()
		{
			delete ptr;
		}
	};
}
void main22()
{
	using namespace nm22;
	Smart sm1;
	Smart sm2;
	Smart sm3 (sm1);
	sm2 = sm3;

}