#include<iostream>
using namespace std;
namespace nm20
{


	class CA
	{
		bool isOnHeap;
		static bool gHeap;
		static int count;
	public:
		CA()
		{
			isOnHeap = gHeap;
			if (--count == 0)
				gHeap = false;
		}
		static void * operator new(size_t size)
		{
			CA *temp = (CA*)malloc(size);
			gHeap = true;
			count = 1;
			return temp;
		}
			static void * operator new[](size_t size)
		{
			CA *temp = (CA*)malloc(size);
			gHeap = true;
			count = size / sizeof(CA);
			return temp;
		}
			void ObjectLocation()
		{
			if (isOnHeap == true)
			{
				cout << "Object on heap" << endl;
			}
			else
			{
				cout << "Object (not) on heap" << endl;
			}
		}
	};
	int CA::count = 0;
	bool CA::gHeap = false;
}
void main20()
{
	using namespace nm20;
	CA obj1;
	CA obj2;
	CA *ptr1 = new CA();
	CA obj3;
	CA *ptr2 = new CA();
	CA *ptr3 = new CA();
	cout << "__________________________" << endl;
	obj1.ObjectLocation();
	obj2.ObjectLocation();
	obj3.ObjectLocation();
	cout << "__________________________" << endl;
	ptr1->ObjectLocation();
	ptr2->ObjectLocation();
	ptr3->ObjectLocation();
	cout << "__________________________" << endl;
	CA *ptr4 = new CA[5];
	/*
		CA *ptr=operator new[](5*sizeof(CA));
		ptr[0]->CA::CA();
		ptr[1]->CA::CA();
		ptr[2]->CA::CA();
		ptr[3]->CA::CA();
		ptr[4]->CA::CA();
	*/
	for (size_t i = 0; i < 5; i++)
	{
		(ptr4 + i)->ObjectLocation();
	}
	CA obj6;
	cout << "__________________________" << endl;
	obj6.ObjectLocation();
}