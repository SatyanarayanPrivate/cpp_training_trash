#include<iostream>
using namespace std;
namespace nm17
{
	class CA
	{
	public:
		CA()
		{
			cout << "CA Ctor" << endl;
			throw 100;
		}
		static void * operator new(size_t size)
		{
			cout << "Custom new operator CA " << endl;
			return malloc(size);
		}
			~CA()
		{
			cout << "CA D-tor" << endl;
		}
	};


	void main17_1()
	{
		CA *obj = NULL;
		try
		{
			obj = new CA();
			/*
					CA *temp=CA::operator new();
					try
					{
					temp->CA::CA();
					}
					catch(...)
					{
					free(temp);
					throw;
					}
					obj=temp;
					*/
		}
		catch (int par)
		{
			cout << "int exp=" << par << endl;
		}

		/*

		push	1
		call	??2CA@@SAPAXI@Z				; CA::operator new
		add	esp, 4

		mov	DWORD PTR tv129[ebp], eax
		mov	eax, DWORD PTR tv129[ebp]
		mov	DWORD PTR $T3[ebp], eax
		mov	BYTE PTR __$EHRec$[ebp+12], 1
		cmp	DWORD PTR $T3[ebp], 0
		je	SHORT $LN6@main
		mov	ecx, DWORD PTR $T3[ebp]
		call	??0CA@@QAE@XZ				; CA::CA
		mov	DWORD PTR tv132[ebp], eax
		mov	ecx, DWORD PTR tv132[ebp]
		mov	DWORD PTR tv71[ebp], ecx
		jmp	SHORT $LN7@main
		$LN6@main:
		mov	DWORD PTR tv71[ebp], 0
		$LN7@main:
		mov	edx, DWORD PTR tv71[ebp]
		mov	DWORD PTR $T2[ebp], edx
		mov	BYTE PTR __$EHRec$[ebp+12], 0
		mov	eax, DWORD PTR $T2[ebp]
		mov	DWORD PTR _obj$[ebp], eax

		*/

		if (obj == NULL)
		{
			cout << "Apple" << endl;
		}
		else
		{
			cout << "Orange" << endl;
			delete obj;
		}

	}

	class CB
	{
	public:
		CB()
		{
			cout << "CB Ctor" << endl;
		}
		~CB()
		{
			cout << "CB D-tor" << endl;
			delete this;
			/*
			this->CB::~CB();
			operator delete();
			*/
		}
		static void operator delete(void *pv)
		{
			cout << "Custom delete operator CA " << endl;
			free(pv);
		}
	};
}
void  main17()
{
	using namespace nm17;
	CB *obj = new CB();

	delete obj;
	/*
	obj->CB::~CB();
	operator delete();
	

	*/
}