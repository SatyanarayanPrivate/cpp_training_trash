#include<iostream>
using namespace std;
namespace nm19
{

	class CA
	{
		CA()
		{
			cout << "CA C-tor" << endl;
		}
		~CA()
		{
			cout << "CA D-tor" << endl;
		}
		static CA* CreateCA()//creator
		{
			//additional business
			return new CA();
		}
		static void ReleaseCA(CA *ptr)
		{
			delete ptr;
		}
	public:
		void fun()
		{
			cout << "CA Fun called " << endl;
		}

		friend class Wrapper;
	};

	class Wrapper
	{
		static void * operator new(size_t size)
		{
			return NULL;
		}
			static void * operator new[](size_t size)
		{
			return NULL;
		}
			static void operator delete(void *pv)
		{
		}
		static void operator delete[](void *pv)
		{
		}
		CA *ptr;
	public:
		Wrapper() :ptr(CA::CreateCA())
		{

		}
		CA* operator->()
		{
			return ptr;
		}
		~Wrapper()
		{
			CA::ReleaseCA(ptr);
		}
	};
}
//CA obj2;
void main19()
{
	using namespace nm19;
	//CA obj1;
	//CA *ptr = CA::CreateCA();//new CA();

	//CA::ReleaseCA(ptr);

	//CA::ReleaseCA(ptr);
	Wrapper wrap1;
	wrap1->fun();
}