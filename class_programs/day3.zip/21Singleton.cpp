#include<iostream>
using namespace std;
namespace nm21
{
	class CA
	{
		CA()
		{
			cout << "CA Ctor" << endl;
		}
		~CA()
		{
			cout << "CA D-tor" << endl;
		}
		static CA *CreateCA()
		{
			if (head == NULL)
				head = new CA();
			return head;
		}
		static void RealeaseCA()
		{
			delete head;
			head = NULL;
		}
		static CA* head;
	public:
		void fun()
		{
			cout << "CA Fun called " << endl;
		}
		friend class Smart;
	};
	CA* CA::head = NULL;


	class Smart
	{
		CA *ptr;
		static int count;
	public:
		Smart() :ptr(CA::CreateCA())
		{
			count++;
		}
		CA* operator->()
		{
			return ptr;
		}
		~Smart()
		{
			if (--count == 0)
			{
				CA::RealeaseCA();
			}
		}
	};
	int Smart::count = 0;
	void fun()
	{
		Smart s;
	}
}
void main21()
{
	using namespace nm21;
	fun();
	Smart s1;
	Smart s2;
	Smart s3;
	Smart s4;
}