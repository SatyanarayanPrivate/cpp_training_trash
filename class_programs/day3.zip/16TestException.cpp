#include<iostream>
using namespace std;
namespace nm16
{
	void VendorApi(int par)
	{
		cout << "Apple" << endl;
		if (10 == par)
		{
			throw 404;
		}
		cout << "Orange" << endl;
	}

	void MyTerminate()
	{
		cout << "Resources De-alloted in MyTerminate..." << endl;
		exit(0);
	}

	void main16_1()
	{
		set_terminate(MyTerminate);
		cout << "Resources alloted in main..." << endl;
		VendorApi(10);
		cout << "Resources De-alloted in main..." << endl;
	}

	class CA
	{
		int x;
		static int y;
	public:
		CA()
		{
			y++;
			x = y;
			cout << "CA Default " << endl;
		}
		CA(CA & par)
		{
			y++;
			x = y;
			cout << "CA Copy " << endl;
		}
		~CA()
		{
			cout << "CA D-tor x=" << x << endl;
		}
	};

	int CA::y = 0;
	void main16_2()
	{
		cout << "Started" << endl;
		try
		{
			CA obj;
			cout << "Pine" << endl;
			throw obj;
			cout << "Orange" << endl;
		}
		catch (int exp)
		{
			cout << "Exp caught int =" << exp << endl;
		}
		catch (CA par)
		{
			cout << "Exp caught CA " << endl;
		}
		cout << "Completed" << endl;
	}


	class CB
	{
	public:
		CB()
		{
			cout << "CB Default " << endl;
		}
		CB(CB & par)
		{
			cout << "CB Copy " << endl;
		}
		~CB()
		{
			cout << "CB D-tor " << endl;
			throw 304;
		}
	};


	void main16_3()
	{
		try
		{
			CB obj;
			throw 100;
		}
		catch (int exp)
		{
			cout << "Exp caught int =" << exp << endl;
		}
		catch (CB par)
		{
			cout << "Exp caught CB " << endl;
		}
	}


	void main16_4()
	{
		try
		{
			try
			{
				throw 100.78;
			}
			catch (int par1)
			{
				cout << "Outer exp =" << par1 << endl;
			}
			cout << "apple" << endl;
		}
		catch (int par)
		{
			cout << "Inner exp int =" << par << endl;
		}
		catch (double par)
		{
			cout << "Inner  exp double =" << par << endl;
		}
		cout << "Banana" << endl;
	}



	void main16_5()
	{
		try
		{
			try
			{
				throw 100;
			}
			//catch (int par1)
			catch (int & par1)//allways catch by reference
			{
				par1 = 999;
				cout << "Outer exp =" << par1 << endl;
				//throw 505;
				//throw par1;
				throw;//rethrow
			}
			cout << "apple" << endl;
		}
		catch (int par)
		{
			cout << "Inner exp int =" << par << endl;
		}
		catch (double par)
		{
			cout << "Inner  exp double =" << par << endl;
		}
		cout << "Banana" << endl;
	}



	void main16_6()
	{
		try
		{
			try
			{
				throw "sachin";
			}
			catch (int & par1)
			{
				cout << "Outer exp =" << par1 << endl;
			}
			catch (...)//catch any
			{
				cout << "general exp caught " << endl;
				throw;
			}
		}
		catch (char *s)
		{
			cout << "Inner str =" << s << endl;
		}

		cout << "Banana" << endl;
	}
}