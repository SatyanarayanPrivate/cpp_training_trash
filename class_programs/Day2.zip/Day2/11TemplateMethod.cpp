#include<iostream>
using namespace std;
namespace nm11
{
	class Bank
	{
	protected:
		void OpenDB()
		{
			cout << "Open Db" << endl;
		}
		void CloseDB()
		{
			cout << "Close Db" << endl;
		}
	public:
		virtual void DoJob() = 0;
		void DoTrans()
		{
			OpenDB();
			DoJob();
			CloseDB();
		}

	};
	class Debit :public Bank
	{
	public:
		Debit()
		{
		}
		void DoJob()
		{
			cout << "Perform Debit job" << endl;
		}
	};
	class Credit :public Bank
	{
	public:
		void DoJob()
		{
			cout << "Perform Credit job" << endl;
		}
	};
}
void main11_1()
{
	using namespace nm11;
	Debit dbt;
	cout << "__________________" << endl;
	dbt.DoTrans();
	cout << "__________________" << endl;
	Credit crd;
	crd.DoTrans();
	cout << "__________________" << endl;
}

//Debit dbt1;
//static Debit db2;

void main11_2()
{
	using namespace nm11;
	//Debit dbt3;
	//static Debit db4;
	Debit *dbt5 = new Debit();
	/*
	push	4
	call	??2@YAPAXI@Z				; operator new
	add	esp, 4
	
	call	??0Debit@@QAE@XZ			; Debit::Debit
	
	mov	DWORD PTR _dbt5$[ebp], ecx
	*/
}