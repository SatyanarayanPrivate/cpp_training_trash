#include<iostream>
using namespace std;
namespace nm13
{
	class IAudio
	{
	public:
		virtual void CreateAudio() = 0;
		virtual void AttachAudio() = 0;
	};
	class IVideo
	{
	public:
		virtual void CreateVideo() = 0;
		virtual void AttachVideo() = 0;
	};
	class IMagnifier
	{
	public:
		virtual void CreateMagnifier() = 0;
		virtual void AttachMagnifier() = 0;
	};

	class IFactory
	{
	public:
		virtual IAudio* BuildAudio() = 0;
		virtual IVideo* BuildVideo() = 0;
		virtual IMagnifier* BuildMagnifier() = 0;
	};

	class IEAudio :public IAudio
	{
	public:
		virtual void CreateAudio()
		{
			cout << "IE Audio Created " << endl;
		}
		virtual void AttachAudio()
		{
			cout << "IE Audio Attached " << endl;
		}
	};

	class IEVideo :public IVideo
	{
	public:
		virtual void CreateVideo()
		{
			cout << "IE Video Created " << endl;
		}
		virtual void AttachVideo()
		{
			cout << "IE Video Attached " << endl;
		}
	};

	class IEMagnifier :public IMagnifier
	{
	public:
		virtual void CreateMagnifier()
		{
			cout << "IE Magnifier Created " << endl;
		}
		virtual void AttachMagnifier()
		{
			cout << "IE Magnifier Attached " << endl;
		}
	};

	class IEFactory :public IFactory
	{
	public:
		virtual IAudio* BuildAudio()
		{
			return new IEAudio();
		}
		virtual IVideo* BuildVideo()
		{
			return new IEVideo();
		}
		virtual IMagnifier* BuildMagnifier()
		{
			return new IEMagnifier();
		}
	};

	//-------------------------

	class ChromeAudio :public IAudio
	{
	public:
		virtual void CreateAudio()
		{
			cout << "Chrome Audio Created " << endl;
		}
		virtual void AttachAudio()
		{
			cout << "Chrome Audio Attached " << endl;
		}
	};

	class ChromeVideo :public IVideo
	{
	public:
		virtual void CreateVideo()
		{
			cout << "Chrome Video Created " << endl;
		}
		virtual void AttachVideo()
		{
			cout << "Chrome Video Attached " << endl;
		}
	};

	class ChromeMagnifier :public IMagnifier
	{
	public:
		virtual void CreateMagnifier()
		{
			cout << "Chrome Magnifier Created " << endl;
		}
		virtual void AttachMagnifier()
		{
			cout << "Chrome Magnifier Attached " << endl;
		}
	};


	class ChromeFactory :public IFactory
	{
	public:
		virtual IAudio* BuildAudio()
		{
			return new ChromeAudio();
		}
		virtual IVideo* BuildVideo()
		{
			return new ChromeVideo();
		}
		virtual IMagnifier* BuildMagnifier()
		{
			return new ChromeMagnifier();
		}
	};

	class FactoryDecider
	{
	public:
		static IFactory * ChooseFactory(int choice)
		{
			//if
			return new IEFactory();
		}
	};
}

void main13()
{
	using namespace nm13;
	IFactory *fact = FactoryDecider::ChooseFactory(10);
	
	IAudio *aud = fact->BuildAudio();
	aud->CreateAudio();
	aud->AttachAudio();
	IVideo *vid = fact->BuildVideo();
	vid->CreateVideo();
	vid->AttachVideo();
	IMagnifier *mag = fact->BuildMagnifier();
	mag->CreateMagnifier();
	mag->AttachMagnifier();

}