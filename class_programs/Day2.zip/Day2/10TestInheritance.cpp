#include<iostream>
using namespace std;
namespace nm10
{
	class CA
	{
	public:
		CA()
		{
			fun();//vptr->vtable[0]()
		}
		virtual void fun()
		{
			cout << "Apple" << endl;
		}
		void myFun()
		{
			fun();//vptr->vtable[0]()
		}
	};
	class CB :public CA
	{
	public:
		CB()
		{
		}
		virtual void fun()
		{
			cout << "Orange" << endl;
		}
	};
}
void main10()
{
	using namespace nm10;
	CB obj;
	obj.myFun();
}