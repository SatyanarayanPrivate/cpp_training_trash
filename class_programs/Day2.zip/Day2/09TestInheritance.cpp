#include<iostream>
using namespace std;
namespace nm9
{
	class CA
	{
	public:
		CA()
		{

		}
		virtual void fun1()
		{
			cout << "\t\t\tCA Fun1 called" << endl;
		}
		virtual void fun2()
		{
			cout << "\t\t\tCA Fun2 called" << endl;
		}
	};
	class CB :public CA
	{
	public:
		CB()
		{
		}
		virtual void fun3()
		{
			cout << "\t\t\tCB Fun3 called" << endl;
		}

		virtual void fun2()
		{
			cout << "\t\t\tCB Fun2 called" << endl;
		}
	};
}
void main9_1()
{
	using namespace nm9;
	CA obj1;
	CB obj2;
	long *vp1 = (long*)&obj1;
	cout << "CA::vftable=" << *vp1 << endl;
	((void(*)())(((long*)*vp1)[0]))();
	((void(*)())(((long*)*vp1)[1]))();
	long *vp2 = (long*)&obj2;
	cout << "CB::vftable=" << *vp2 << endl;
	((void(*)())(((long*)*vp2)[0]))();
	((void(*)())(((long*)*vp2)[1]))();
	((void(*)())(((long*)*vp2)[2]))();

	//LSP--> Liskov's substitution principle

	CA *ptr = &obj2;
	cout << "_____________call through CA *____________CB object " << endl;
	//ptr->CA::CA();
	ptr->fun1();//ptr->vptr->vtable[0]()
	ptr->fun2();//ptr->vptr->vtable[1]()
}