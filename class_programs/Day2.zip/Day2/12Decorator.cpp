#include<iostream>
using namespace std;

namespace nm12
{
	class ILogger
	{
	public:
		virtual void LogMessage(char * msg) = 0;
	};

	class NullLogger :public ILogger
	{
	public:
		NullLogger()
		{
		}
		void LogMessage(char * msg)
		{
			//do nothing
		}
	};

	class LoggerHelper :public ILogger
	{
		ILogger *il;
	public:
		LoggerHelper(ILogger *il) :il(il)
		{
		}
		void LogMessage(char * msg)
		{
			il->LogMessage(msg);
		}
	};

	class ConsoleLogger :public LoggerHelper
	{
	public:
		ConsoleLogger(ILogger *il) :LoggerHelper(il)
		{
		}
		void LogMessage(char * msg)
		{
			cout << "ConsoleLogger msg=" << msg << endl;
			LoggerHelper::LogMessage(msg);
		}
	};

	class FileLogger :public LoggerHelper
	{
	public:
		FileLogger(ILogger *il) :LoggerHelper(il)
		{
		}
		void LogMessage(char * msg)
		{
			cout << "FileLogger msg=" << msg << endl;
			LoggerHelper::LogMessage(msg);
		}
	};

	class ServiceLogger :public LoggerHelper
	{
	public:
		ServiceLogger(ILogger *il) :LoggerHelper(il)
		{
		}
		void LogMessage(char * msg)
		{
			cout << "ServiceLogger msg=" << msg << endl;
			LoggerHelper::LogMessage(msg);
		}
	};

	class ETWLogger :public LoggerHelper
	{
	public:
		ETWLogger(ILogger *il) :LoggerHelper(il)
		{
		}
		void LogMessage(char * msg)
		{
			cout << "ETWLogger msg=" << msg << endl;
			LoggerHelper::LogMessage(msg);
		}
	};

	class LoggerFactory
	{
	public:
		static ILogger * CreateLoggers()
		{
			return new ETWLogger(new ServiceLogger(new ConsoleLogger(new FileLogger(new NullLogger()))));
		}
	};
}

void main12()
{
	using namespace nm12;
	cout << "Business Started ...." << endl;
	ILogger *il=LoggerFactory::CreateLoggers();
	il->LogMessage("India is great!!!");
	
	cout << "Business Completed ...." << endl;
		il->LogMessage("India wins Pakisthan in WC !!!");
}