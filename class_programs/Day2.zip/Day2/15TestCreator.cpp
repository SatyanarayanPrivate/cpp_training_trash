#include<iostream>
#include<map>
using namespace std;

class IFile
{
public:
	virtual void DoProcessing() = 0;
};

class BMP :public IFile
{
public:
	BMP(){
		cout << "BMP Ctor" << endl;
	}
	void DoProcessing()
	{
		cout << "BMP Processed " << endl;
	}
};

IFile* CreateBMP()
{
	return new BMP();
}


class JPEG :public IFile
{
public:
	JPEG(){
		cout << "JPEG Ctor" << endl;
	}
	void DoProcessing()
	{
		cout << "JPEG Processed " << endl;
	}
};

IFile* CreateJPEG()
{
	return new JPEG();
}

class WMF :public IFile
{
public:
	WMF(){
		cout << "WMF Ctor" << endl;
	}
	void DoProcessing()
	{
		cout << "WMF Processed " << endl;
	}
};
IFile* CreateWMF()
{
	return new WMF();
}

class Register
{
	static Register reg;
public:
	static map<int, IFile*(*)()> myMap;

	Register()
	{
		//myMap[10] = [](){return (IFile*)new BMP(); };
		//myMap[20] = [](){return (IFile*)new JPEG(); };
		//myMap[30] = [](){return (IFile*)new WMF(); };

		//myMap[10] = &CreateBMP;
		//myMap[20] = &CreateJPEG;
		//myMap[30] = &CreateWMF;
		DoRegister(10, &CreateBMP);
		DoRegister(20, &CreateJPEG);
		DoRegister(30, &CreateWMF);
	}
	static  void DoRegister(int choice, IFile*(*fp)())
	{
		myMap[choice] = fp;
	}
	static IFile* BuildFileObject(int choice)
	{
		return myMap[choice]();
	}
};
map<int, IFile*(*)()> Register::myMap;
Register Register::reg;



void main()
{

	cout << "Enter a choice " << endl;
	int n; cin >> n;
	IFile * file = Register::BuildFileObject(n);
	file->DoProcessing();
}